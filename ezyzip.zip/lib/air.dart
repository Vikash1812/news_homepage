import 'package:flutter/material.dart';
class AirPage extends StatefulWidget {
  const AirPage({Key? key}) : super(key: key);

  @override
  State<AirPage> createState() => _AirPageState();
}

class _AirPageState extends State<AirPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child:
        Stack(
          children: [
            Image.network('https://images.pexels.com/photos/46148/aircraft-jet-landing-cloud-46148.jpeg?cs=srgb&dl=pexels-pixabay-46148.jpg&fm=jpg',
            fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
            ),
         Container(
           child: IconButton(onPressed: (){
             Navigator.pushNamed(context, 'home');
           },icon: Icon(Icons.arrow_back,size: 35,color: Colors.white),),
         ),
           Stack(
             children: const [
               Padding(
                 padding: EdgeInsets.only(top: 400,
                 left: 10),
                 child: Text('Boeing dedicates 100 milions to victims 737 Max crashes',
                 style: TextStyle(color: Colors.white,
                 fontSize: 29,
                   fontWeight: FontWeight.bold,
                 ),
                 ),
               ),
               Padding(
                 padding: EdgeInsets.only(top: 500,
                 left: 10),
                 child: Text('CNN',style: TextStyle(color: Colors.white70,
                   fontSize: 20,
                   fontWeight: FontWeight.bold,
                 ),),
               ),
               Padding(
                 padding: EdgeInsets.only(top: 500,left: 380),
                 child: Text('2019-07-03',style: TextStyle(color: Colors.white70,
                   fontSize: 20,
                   fontWeight: FontWeight.bold,
                 )),
               ),
               Padding(
                 padding: EdgeInsets.only(top: 550,left: 10),
                 child: Text('Boeing Will Pay out 100 Million to help support the families and communication of the 346 people who dies in two Max crashes in the last year',
                 style: TextStyle(
                   color: Color(0xFFbababa),
                 fontSize: 14,
                   fontWeight:FontWeight.bold
                 ),),
               ),
             ],
           )
          ],
        ),
      ),
    );
  }
}
