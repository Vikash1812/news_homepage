import 'package:flutter/material.dart';
class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF464646),
      appBar: AppBar(
        backgroundColor: Color(0xFF000000),
        title: Text('HEADLINES',style: TextStyle(fontSize: 29,
          fontWeight: FontWeight.bold,
          color: Color(0xFFffffff)

        ),),
      ),
     body: Container(
       child: Stack(
         children: [
           ListView(
             children: [
               Padding(
                 padding: const EdgeInsets.all(8.0),
                 child: Container(
                   height: 180,
                   child: Card(
                     child:InkWell(onTap: (){
                       Navigator.pushNamed(context,'air');
                     },
                     child: Ink.image(image: NetworkImage('https://images.pexels.com/photos/163792/model-planes-airplanes-miniatur-wunderland-hamburg-163792.jpeg?cs=srgb&dl=pexels-pixabay-163792.jpg&fm=jpg'),
                     fit: BoxFit.cover,
                       child: const Padding(
                         padding: EdgeInsets.only(top: 100,left: 10),
                         child: Text('Boeing dedicates 100 milion to victims 737 Max crashes',
                             style: TextStyle(color: Colors.white,
                               fontSize: 16,
                               fontWeight: FontWeight.bold,
                             )
                         ),
                       ),
                     ),
                     )
                   ),
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.all(8.0),
                 child: Container(
                   height: 180,
                   child: Card(
                       child:InkWell(onTap: (){},
                         child: Ink.image(image: NetworkImage('https://image-cdn.hypb.st/https%3A%2F%2Fhypebeast.com%2Fimage%2F2019%2F07%2Fhot-toys-spider-man-far-from-home-spider-drone-release-0000.jpg?w=960&cbr=1&q=90&fit=max'),
                           fit: BoxFit.cover,
                           child: const Padding(
                             padding: EdgeInsets.only(top:100,left: 10 ),
                             child: Text('Spider Man For From Home Endgame, and more all 23 Marval Movie Ranked',
                                 style: TextStyle(color: Colors.white,
                                     fontSize: 16,
                                 fontWeight: FontWeight.bold
                                 )),
                           ),
                         ),
                       )
                   ),
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.all(8.0),
                 child: Container(
                   height: 180,
                   child: Card(
                       child:InkWell(onTap: (){},
                         child: Ink.image(image: NetworkImage('https://images.hindustantimes.com/img/2021/04/06/550x309/AFP_97E8TZ_1617720027049_1617720037507.jpg'),
                           fit: BoxFit.cover,
                           child: const Padding(
                             padding: EdgeInsets.only(top: 100,left: 10),
                             child: Text('In US House speaker fight, Trump gets one vote, members laugh. Watch',
                                 style: TextStyle(color: Colors.white,
                                     fontSize: 18,
                                 fontWeight: FontWeight.bold
                                 )),
                           ),
                         ),
                       )
                   ),
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.all(8.0),
                 child: Container(
                   height: 180,
                   child: Card(
                       child:InkWell(onTap: (){},
                         child: Ink.image(image: NetworkImage('https://akm-img-a-in.tosshub.com/indiatoday/images/story/202212/cold_wave_1-sixteen_nine.jpg?VersionId=Z9A8aAqtCX4HtFTL63E__D8Zaz2E1onD'),
                           fit: BoxFit.cover,
                           child: Padding(
                             padding: const EdgeInsets.only(top: 100,left: 10),
                             child: Text('U.P schools closed in Mainpuri district till January 14 for winter vacations',
                                 style: TextStyle(color: Colors.white,
                                     fontSize: 18,
                                 fontWeight: FontWeight.bold
                                 )),
                           ),
                         ),
                       )
                   ),
                 ),
               ),
               Padding(
                 padding: const EdgeInsets.all(8.0),
                 child: Container(
                   height: 180,
                   child: Card(
                       child:InkWell(onTap: (){},
                         child: Ink.image(image: NetworkImage('https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/1200px-Image_created_with_a_mobile_phone.png'),
                           fit: BoxFit.cover,
                           child: const Padding(
                             padding: EdgeInsets.only(top: 100,left: 10),
                             child: Text('Lifeline of NCR Delhi Metro turned 20 in 2022',
                                 style: TextStyle(color: Colors.white,
                                     fontSize: 18,
                                 fontWeight: FontWeight.bold
                                 )),
                           ),
                         ),
                       )
                   ),
                 ),
               ),
             ],
           )
         ],
       ),
     ),
    );
  }
}
