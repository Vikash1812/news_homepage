import 'dart:js';

import 'package:untitled3/air.dart';
import 'package:untitled3/home.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    initialRoute: 'home',
    routes: {
      'home': (context) => MyHomePage(),
      'air': (context) => AirPage()
    },
  )
  );
}
